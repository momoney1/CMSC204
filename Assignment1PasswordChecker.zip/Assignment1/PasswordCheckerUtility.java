package Assignment1;
import java.util.ArrayList;
/**
 * A utility class that contains methods that verify the validity of passwords
 * @author Moe Diakite
 *
 */
public class PasswordCheckerUtility {
	/**
	 * A no arg constructor 
	 */
	public PasswordCheckerUtility()  {
		
	}
	/**
	 * A method that accepts a password value, and checks it's valitdity
	 * @param passwordString
	 * @return true or false
	 */
	static boolean isValidPassword (String passwordString) throws LengthException,  NoUpperAlphaException, NoDigitException,
	NoLowerAlphaException, InvalidSequenceException{
		boolean capLetters = false;
		boolean lowerLetters = false;
		int count = 0;
		if(passwordString.length() < 6) {
			throw new LengthException();
		}
		for(int i = 0; i < passwordString.length(); i++) {
			if(Character.isUpperCase(passwordString.charAt(i))) {
				capLetters = true;
			}
			if(Character.isLowerCase(passwordString.charAt(i))) {
				lowerLetters = true;
			}
		}
		if(capLetters == false) {
			throw new NoUpperAlphaException();
		}
		
		if(lowerLetters == false) {
			throw new NoLowerAlphaException();
		}
		if(!passwordString.matches(".*[1-9].*")) {
			throw new NoDigitException();
		}
		for(int i = 0; i < passwordString.length() - 2; i++) {
				if(passwordString.charAt(i) == passwordString.charAt(i + 1) && passwordString.charAt(i) == passwordString.charAt(i + 2)) {
					if(Character.isLowerCase(passwordString.charAt(i)) && Character.isLowerCase(passwordString.charAt(i + 1)) && 
							Character.isLowerCase(passwordString.charAt(i + 2))|| 
							Character.isUpperCase(passwordString.charAt(i)) && Character.isUpperCase(passwordString.charAt(i + 1)))
					throw new InvalidSequenceException();
				}
		}
		
		return true;
	}
	/**
	 * A method that determins whether or not a password is weak
	 * @param passwordString
	 * @return true or false
	 */
	static boolean isWeakPassword(String passwordString) {
		if(passwordString.length() >= 6 && passwordString.length() <= 9) {
			return true;
		}
		return false;
	}
	/**
	 * A method that accepts a list of passwords, and returns all the invalid ones
	 * @param passwords
	 * @return invalid passwords
	 */
	static ArrayList<String> invalidPasswords(ArrayList<String> passwords){
		ArrayList<String> invalid = new ArrayList<>();
		for(int i = 0; i < passwords.size(); i++) {
			try {
				isValidPassword(passwords.get(i));
			}
			catch(RuntimeException e) {
				if(e instanceof LengthException) {
					invalid.add(passwords.get(i) + " "+ e.getMessage());
				}
				else if(e instanceof NoUpperAlphaException) {
					invalid.add(passwords.get(i) + " "+ e.getMessage());
				}
				else if(e instanceof NoLowerAlphaException) {
					invalid.add(passwords.get(i) + " "+ e.getMessage());
				}
				else if(e instanceof NoDigitException) {
					invalid.add(passwords.get(i) + " "+ e.getMessage());
				}
				else if(e instanceof InvalidSequenceException) {
					invalid.add(passwords.get(i) + " "+ e.getMessage());
				}
			}
			
		}
		return invalid;
	}
}
